fx_version 'cerulean'
game 'gta5'

author 'TATITUPTECH'
description 'QBcore Escort/Protection Mission Script'
version '1.1.0'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'locales/en.lua',
    'config.lua'
}

client_scripts {
    'client/utils.lua',
    'client/escort.lua',
    'client/threats.lua',
    'client/zones.lua'
}

server_scripts {
    '@qb-core/import.lua',
    'server/main.lua'
}