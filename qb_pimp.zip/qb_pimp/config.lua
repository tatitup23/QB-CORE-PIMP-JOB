Config = {}

Config.NpcModel = "s_f_y_hooker_01"
Config.StartLocation = vector4(223.5, -871.0, 30.5, 160.0)
Config.EndLocations = {
    vector3(278.7, -830.6, 29.4),
    vector3(310.1, -768.3, 29.3),
    vector3(399.6, -903.1, 29.4)
}
Config.Reward = {min = 400, max = 900}
Config.EscortDistance = 30.0 -- Max distance player can be from NPC
Config.FailDistance = 45.0   -- Fail mission if further than this
Config.CloseEnough = 3.0     -- Distance to destination to succeed
Config.Threat = {
    chance = 0.3, -- 30% chance for a threat per checkpoint
    models = {"g_m_y_mexgoon_01", "g_m_y_ballaeast_01"},
    weapon = `WEAPON_PISTOL`,
    minPerEvent = 1,
    maxPerEvent = 2
}
Config.MissionCooldown = 180 -- seconds
Config.Language = "en"