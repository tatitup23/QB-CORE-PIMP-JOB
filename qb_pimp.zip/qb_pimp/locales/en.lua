Lang = {
    ['start_prompt'] = "~g~[E]~w~ Talk to the prostitute to start escort mission",
    ['escort_start'] = "Escort the prostitute to her client. Protect her!",
    ['escort_complete'] = "Success! You protected the prostitute and got paid.",
    ['escort_failed_dead'] = "Mission failed. The prostitute was killed.",
    ['escort_failed_far'] = "Mission failed. You left the prostitute behind.",
    ['escort_failed_abort'] = "Mission aborted.",
    ['escort_cooldown'] = "You must wait before starting another mission.",
    ['escort_in_progress'] = "Mission already in progress.",
    ['escort_npc_busy'] = "Prostitute is busy. Try again later.",
    ['escort_under_attack'] = "Watch out! Enemies are attacking!",
}