QBCore = exports['qb-core']:GetCoreObject()

function Notify(msg, type)
    QBCore.Functions.Notify(msg, type or "primary")
end

function DrawText3D(x, y, z, text)
    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

function GetRandomEndLocation()
    local idx = math.random(1, #Config.EndLocations)
    return Config.EndLocations[idx]
end

function GetRandomReward()
    return math.random(Config.Reward.min, Config.Reward.max)
end

function TableLength(tbl)
    local count = 0
    for _ in pairs(tbl) do count = count + 1 end
    return count
end