local escorting = false
local npc, blip, destBlip
local escortMission = {}
local lastMissionTime = 0

function SpawnEscortNpc()
    RequestModel(Config.NpcModel)
    while not HasModelLoaded(Config.NpcModel) do Wait(10) end
    npc = CreatePed(4, Config.NpcModel, Config.StartLocation.x, Config.StartLocation.y, Config.StartLocation.z-1, Config.StartLocation.w, false, true)
    SetEntityAsMissionEntity(npc, true, true)
    SetPedFleeAttributes(npc, 0, 0)
    SetPedCombatAttributes(npc, 17, 1)
    SetBlockingOfNonTemporaryEvents(npc, true)
    SetPedCanRagdoll(npc, false)
    FreezeEntityPosition(npc, false)
    return npc
end

function StartEscortMission()
    if escorting then Notify(Lang['escort_in_progress'], "error") return end
    if GetGameTimer() - lastMissionTime < Config.MissionCooldown * 1000 then
        Notify(Lang['escort_cooldown'], "error")
        return
    end
    escorting = true
    lastMissionTime = GetGameTimer()
    local dest = GetRandomEndLocation()
    local reward = GetRandomReward()
    escortMission = { destination = dest, reward = reward }
    if not npc or not DoesEntityExist(npc) then npc = SpawnEscortNpc() end
    blip = AddBlipForEntity(npc)
    SetBlipSprite(blip, 280)
    SetBlipColour(blip, 48)
    SetBlipScale(blip, 0.7)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Escort Target")
    EndTextCommandSetBlipName(blip)
    destBlip = AddBlipForCoord(dest.x, dest.y, dest.z)
    SetBlipSprite(destBlip, 1)
    SetBlipColour(destBlip, 2)
    SetBlipScale(destBlip, 0.6)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Client Location")
    EndTextCommandSetBlipName(destBlip)
    TaskGoStraightToCoord(npc, dest.x, dest.y, dest.z, 1.0, -1, 0.0, 0.0)
    Notify(Lang['escort_start'], "primary")
end

function EndEscortMission(reason)
    escorting = false
    if blip then RemoveBlip(blip) end
    if destBlip then RemoveBlip(destBlip) end
    if DoesEntityExist(npc) then DeletePed(npc) end
    npc, blip, destBlip = nil, nil, nil
    if reason == "success" then
        TriggerServerEvent("escort:reward", escortMission.reward)
        Notify(Lang['escort_complete'], "success")
    elseif reason == "dead" then
        Notify(Lang['escort_failed_dead'], "error")
    elseif reason == "far" then
        Notify(Lang['escort_failed_far'], "error")
    elseif reason == "abort" then
        Notify(Lang['escort_failed_abort'], "error")
    end
end

Citizen.CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)
        if not escorting then
            if #(pos - vector3(Config.StartLocation.x, Config.StartLocation.y, Config.StartLocation.z)) < 2.0 then
                DrawText3D(Config.StartLocation.x, Config.StartLocation.y, Config.StartLocation.z+1.0, Lang['start_prompt'])
                if IsControlJustReleased(0, 38) then -- E
                    StartEscortMission()
                end
            end
        else
            if not npc or not DoesEntityExist(npc) or IsPedDeadOrDying(npc, true) then
                EndEscortMission("dead")
            else
                local npcPos = GetEntityCoords(npc)
                if #(pos - npcPos) > Config.FailDistance then
                    EndEscortMission("far")
                elseif #(npcPos - escortMission.destination) < Config.CloseEnough then
                    EndEscortMission("success")
                end
            end
        end
    end
end)