RegisterNetEvent("escort:threatAttack", function(coords)
    local n = math.random(Config.Threat.minPerEvent, Config.Threat.maxPerEvent)
    for i = 1, n do
        local model = Config.Threat.models[math.random(1, #Config.Threat.models)]
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(10) end
        local spawnPos = coords + vector3(math.random(-10,10), math.random(-10,10), 0)
        local threatPed = CreatePed(4, model, spawnPos.x, spawnPos.y, spawnPos.z, math.random(0,360)*1.0, true, true)
        GiveWeaponToPed(threatPed, Config.Threat.weapon, 40, false, true)
        SetPedCombatAttributes(threatPed, 46, 1)
        TaskCombatPed(threatPed, npc, 0, 16)
    end
    Notify(Lang['escort_under_attack'], "error")
end)

-- Threat triggering logic in escort
